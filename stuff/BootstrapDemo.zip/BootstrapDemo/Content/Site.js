﻿$(document).ready(function () {
    // alert('ready');

    $('#animatedButton').click(function (e) {
        var originalWidth = $(this).width();
        var originalHeight = $(this).height();
        var maxWidth = $(this).parent().width();
        var maxHeight = maxWidth * (originalHeight / originalWidth);
        $(this).animate({ width: maxWidth, height: maxHeight }, "slow");
        $(this).animate({ width: originalWidth, height: originalHeight }, "slow");
    });

    $('.pdctp-checkbox').change(function (e) {
        var checkbox = $(this);
        var checked = checkbox.prop('checked');
        switch (checkbox.attr("id")) {
            case 'checkboxTS':
                showHidePeople(checked, '.pdctp-ts');
                break;
            case 'checkboxSTS':
                showHidePeople(checked, '.pdctp-sts');
                break;
            case 'checkboxTL':
                showHidePeople(checked, '.pdctp-tl');
                break;
        }
    });

    function showHidePeople(checked, className) {
        if (checked)
        {
            $(className).removeClass('hidden');
        }
        else
        {
            $(className).addClass('hidden');
        }
    }
});