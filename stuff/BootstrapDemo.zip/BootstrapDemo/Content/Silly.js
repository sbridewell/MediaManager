﻿$(document).ready(function () {
    $('#clickMe').mouseover(function (e) {
        var sprints = Math.floor(Math.random() * 5) + 1;
        for (var i = 0; i < sprints; i++) {
            runAway($(this))
        }
    });

    function runAway(control) {
        var maxX = $(window).width() - control.width();
        var maxY = $(window).height() - control.height();
        var newX = Math.floor(Math.random() * maxX) + 'px';
        var newY = Math.floor(Math.random() * maxY) + 'px';
        control.animate({
            left: newX,
            top: newY,
        });
    }
});