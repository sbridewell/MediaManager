﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace BgmStuff
{
    /// <summary>
    /// Helper class with methods for converting between <see cref="DateTime"/>,
    /// Gregorian date string in <c>dd/MM/yyyy</c> format and Julian date string in
    /// <c>yyjjj</c> format, and for validating Julian and Gregorian date strings.
    /// </summary>
    public class ProcessingDate
    {
        #region constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="ProcessingDate"/> class.
        /// </summary>
        /// <param name="value">The <see cref="DateTime"/> represented by this instance.</param>
        public ProcessingDate(DateTime value)
        {
            Value = value;
        }
        #endregion

        #region Value property
        /// <summary>
        /// Gets or sets the <see cref="DateTime"/> value of the date.
        /// </summary>
        public DateTime Value { get; set; }
        #endregion

        #region static FromJulian method
        /// <summary>
        /// Attempts to construct a <see cref="ProcessingDate"/> from the supplied
        /// Julian date string.
        /// Use this method if you're sure you've already got a valid Julian date string,
        /// otherwise use the <c>IsValidJulian(string, out DateTime)</c> method
        /// and test that the return value is true before attempting to use the 
        /// resulting <see cref="DateTime"/> object.
        /// </summary>
        /// <param name="julianDate">The Julian date to convert in <c>yyjjj</c> format.</param>
        /// <returns>The supplied Julian date as a <see cref="ProcessingDate"/>.</returns>
        /// <exception cref="FormatException">
        /// The supplied string is not a valid Julian date.
        /// </exception>
        public static ProcessingDate FromJulian(string julianDate)
        {
            DateTime value;
            if (IsValidJulian(julianDate, out value))
            {
                ProcessingDate returnValue = new ProcessingDate(value);
                return returnValue;
            }
            else
            {
                throw new FormatException("The supplied string '" + julianDate + "' is not a valid Julian date");
            }
        }
        #endregion

        #region static FromGregorian method
        /// <summary>
        /// Attempts to construct a <see cref="ProcessingDate"/> from the supplied
        /// Gregorian date string.
        /// Use this method if you're sure you've already got a valid Gregorian date string,
        /// otherwise use the <c>IsValidGregorian(string, out DateTime)</c> method
        /// and test that the return value is true before attempting to use the 
        /// resulting <see cref="DateTime"/> object.
        /// </summary>
        /// <param name="gregorianDate">The Gregorian date to convert.</param>
        /// <returns>The supplied Gregorian date as a <see cref="ProcessingDate"/>.</returns>
        /// <exception cref="FormatException">
        /// The supplied string is not a valid Gregorian date.
        /// </exception>
        public static ProcessingDate FromGregorian(string gregorianDate)
        {
            DateTime gregorianDateTime;
            bool success = IsValidGregorian(gregorianDate, out gregorianDateTime);
            if (success)
            {
                return new ProcessingDate(gregorianDateTime);
            }
            else
            {
                throw new FormatException("The supplied string '" + gregorianDate + "' is not a valid Gregorian date");
            }
        }
        #endregion

        #region static IsValidJulian methods
        /// <summary>
        /// Determines whether the supplied string is a valid Julian date.
        /// </summary>
        /// <param name="julianDate">The string to validate.</param>
        /// <returns>
        /// True if the supplied string is a valid Julian date, otherwise false.
        /// </returns>
        public static bool IsValidJulian(string julianDate)
        {
            DateTime value;
            return IsValidJulian(julianDate, out value);
        }

        /// <summary>
        /// Determines whether the supplied string is a valid Julian date.
        /// </summary>
        /// <param name="julianDate">The string to validate.</param>
        /// <param name="value">
        /// The <see cref="DateTime"/> represented by the supplied Julian date string.
        /// </param>
        /// <returns>
        /// True if the supplied string is a valid Julian date, otherwise false.
        /// </returns>
        public static bool IsValidJulian(string julianDate, out DateTime value)
        {
            value = new DateTime();

            // must be 5 characters numeric
            Match m = Regex.Match(julianDate, "[0-9]{5}");
            if (!m.Success)
            {
                return false;
            }

            // get the year and day number - the string to int conversion and substring 
            // shouldn't fail because the regex has already verified that we're dealing 
            // with a 5 digit numeric string
            int yy = int.Parse(julianDate.Substring(0, 2));
            int jjj = int.Parse(julianDate.Substring(2, 3));

            // The Julian date format doesn't include the century part of the year
            // so I've had to make some assumptions about it.
            // I'm writing this in November 2017 and the retention period for the 
            // data that this application enquires upon is 3 months, so even if we 
            // were to change the retention period in production today to infinity,
            // there'll never be any data earlier than August 2017 to enquire on.
            // So the earliest possible century is the 21st century.

            // What is the latest possible century?
            // I can't be sure, but I'm assuming only the 21st century is possible.
            // In the unlikely event that this application is still in use in 2099,
            // if I'm still alive and still in posession of all my marbles, feel
            // free to call me out of retirement to change this to support the 22nd
            // century ;-)

            int ccyy = yy + 2000;

            // check that the day number is within the number of days in the year
            int firstDayOfYear = new DateTime(ccyy, 1, 1).DayOfYear; // should always be 1
            int lastDayOfYear = new DateTime(ccyy, 12, 31).DayOfYear; // either 365 or 366
            if (jjj < firstDayOfYear || jjj > lastDayOfYear)
            {
                return false;
            }

            // If we get this far then it's valid. so get the DateTime value.
            // Start from the final day of the previous year and add the Julian day number.
            value = new DateTime(ccyy - 1, 12, 31).AddDays(jjj);
            return true;
        }
        #endregion

        #region static IsValidGregorian methods
        /// <summary>
        /// Determines whether the supplied string is a valid Gregorian date.
        /// </summary>
        /// <param name="gregorinDate">The string to validate.</param>
        /// <param name="value">
        /// The <see cref="DateTime"/> represented by the supplied Gregorian date string.
        /// </param>
        /// <returns>
        /// True if the supplied string is a valid Gregorian date, otherwise false.
        /// </returns>
        public static bool IsValidGregorian(string gregorianDate)
        {
            DateTime value;
            return IsValidGregorian(gregorianDate, out value);
        }

        /// <summary>
        /// Determines whether the supplied string is a valid Gregorian date.
        /// </summary>
        /// <param name="gregorinDate">The string to validate.</param>
        /// <param name="value">
        /// The <see cref="DateTime"/> represented by the supplied Gregorian date string.
        /// </param>
        /// <returns>
        /// True if the supplied string is a valid Gregorian date, otherwise false.
        /// </returns>
        public static bool IsValidGregorian(string gregorianDate, out DateTime value)
        {
            bool success = DateTime.TryParse(gregorianDate, out value);
            return success;
        }
        #endregion

        #region ToJulian method
        /// <summary>
        /// Converts the value of the current instance to a Julian date string in
        /// <c>yyjjj</c> format.
        /// </summary>
        /// <returns>The Julian date string.</returns>
        public string ToJulian()
        {
            string julianDay = Value.DayOfYear.ToString().PadLeft(3, '0');
            string julianYear = (Value.Year % 100).ToString().PadLeft(2, '0');
            string result = julianYear + julianDay;
            return result;
        }
        #endregion

        #region ToGregorian method
        /// <summary>
        /// Converts the value of the current instance to a Gregorian date in
        /// <c>dd/MM/yyyy</c> format.
        /// </summary>
        /// <returns>The Gregorian date string.</returns>
        public string ToGregorian()
        {
            return Value.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
        }
        #endregion
    }
}