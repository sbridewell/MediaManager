﻿$(document).ready(function () {

    // alert('ready');

    // Event handler to show or hide the inbound and outbound files drop-downlists
    // depending on which radio button is selected.
    // Parameter e: the event being handled.
    $('#radioGroup2 input[type="radio"]').change(function (e) {
        var radio1 = $('#radio1');
        if (radio1.is(':checked'))
        {
            $('#divRadio1').addClass("in");
            $('#divRadio2').removeClass("in");
        }
        else
        {
            $('#divRadio1').removeClass("in");
            $('#divRadio2').addClass("in");
        }
    });

    // Event handler to enable or disable checkboxes depending on which radio button
    // is selected.
    $('#radioGroup1 input[type="radio"]').change(function (e) {
        var checkboxes = $('#divWithCheckboxes div input[type="checkbox"]');
        var radioUseTheCheckboxes = $('#RadioUseTheCheckboxes');
        if (radioUseTheCheckboxes.is(':checked'))
        {
            checkboxes.removeAttr('disabled');
        }
        else
        {
            checkboxes.attr('disabled', 'disabled');
        }
    });

    // TODO: change event handlers to validate control contents first before attempting to convert
    // TODO: display result of validation
    // TODO: when a Gregorian date has been validated, update it to the preferred format

    // Event handler for the "Date from" field's value changing.
    $('#DateFrom').change(function () {
        gregChangeHandler($(this), $('#JulianFrom'));
    });

    // Event handler for the "Date from" field's value changing.
    $('#DateTo').change(function () {
        gregChangeHandler($(this), $('#JulianTo'));
    });

    // Event handler to populate the "Date from" field when the value of the
    // "Julian date from" field changes.
    $('#JulianFrom').change(function () {
        julToGreg($(this).val(), $('#DateFrom'));
    });

    // Event handler to populate the "Date to" field when the value of the
    // "Julian date to" field changes.
    $('#JulianTo').change(function () {
        julToGreg($(this).val(), $('#DateTo'));
    });

    // Generic function for a Gregorian date text box's value changing.
    // Validates that the string can be converted to a Gregorian date.
    // Gets the Gregorian date in the preferred dd/MM/yyyy format and replaces
    // the source text box's value with the date in that preferred format.
    // Updates the value of a Julian date text box with the date in Julian format.
    // Parameter sourceControl: The Gregorial date text box whose event we're handling.
    // Parameter targetControl: The Julian date text box to update.
    // TODO: look at MVC client side validation, is all this necessary?
    function gregChangeHandler(sourceControl, targetControl) {
        var gregDate = sourceControl.val();
        alert(gregDate);
        $.ajax({
            url: "ValidateGregorian",
            data: { gregorianDate: gregDate },
            success: function (isValid) {
                if (isValid == "True")
                {
                    $.ajax({
                        url: "FormatGregorian",
                        data: { gregorianDate: gregDate },
                        success: function (formattedDate) {
                            sourceControl.val(formattedDate);
                            $.ajax({
                                url: "ConvertGregorianToJulian",
                                data: { gregorianDate: gregDate },
                                success: function (julDate) {
                                    targetControl.val(julDate);
                                    // FIXME: not disabling the submit button
                                    $('#submitButton').removeAttr('disabled');
                                },
                                error: function (data, status, xhr) {
                                    handleAjaxError("Error converting gregorian to Julian: ", data, status, xhr);
                                }
                            })
                        },
                        error: function (data, status, xhr) {
                            handleAjaxError("Error reformatting gregorian date: ", data, status, xhr);
                        }
                    })
                }
                else
                {
                    alert("Not valid");
                    // FIXME: not disabling the submit button
                    $('#submitButton').attr('disabled');
                }
            },
            error: function (data, status, xhr) {
                handleAjaxError("Error validating gregorian date: ", data, status, xhr);
            }

        })
    }

    // Function to pass a Julian date to the controller using ajax, and to update a
    // target control with the returned Gregorian date.
    // Parameter julDate: The Julian date to convert.
    // Parameter targetControl: jQuery reference to the control to display the result in.
    function julToGreg(julDate, targetControl) {
        $.get('Home/ConvertJulianToGregorian', { julianDate: julDate }, function (data) {
            //alert('returned ' + data);
            //alert('updating ' + targetControl.attr('id'));
            //alert('target\'s original value: ' + targetControl.val());
            targetControl.val(data);
        });
    }

    function handleAjaxError(appMessage, data, status, xhr) {
        alert("Ajax error! " + appMessage + "\n" + JSON.stringify(data, null, 2) + "\n" + JSON.stringify(xhr, null, 2));
    }
});