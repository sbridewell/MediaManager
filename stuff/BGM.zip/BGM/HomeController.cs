﻿using BgmStuff.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BgmStuff.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Search()
        {
            ProcessingDate today = new ProcessingDate(DateTime.Now);
            var model = new SearchModel()
            {
                DateFrom = today.ToGregorian(),
                DateTo = today.ToGregorian(),
                JulianFrom = today.ToJulian(),
                JulianTo = today.ToJulian(),
            };

            return View(model);
        }

        [HttpPost]
        public ActionResult Search(SearchModel model)
        {
            model.SearchResults = string.Empty;
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            model.SearchResults = "imagine your search results are here";
            return View(model);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        #region ValidateGregorian
        /// <summary>
        /// Validates the supplied string as a Gregorian date.
        /// </summary>
        /// <param name="gregorianDate">The string to validate.</param>
        /// <returns>True if the string represents a valid Gregorian date, otherwise false.</returns>
        public bool ValidateGregorian(string gregorianDate)
        {
            return ProcessingDate.IsValidGregorian(gregorianDate);
        }
        #endregion

        #region ValidateJulian
        /// <summary>
        /// Validates the supplied string as a Julian date.
        /// </summary>
        /// <param name="gregorianDate">The string to validate.</param>
        /// <returns>True if the string represents a valid Julian date, otherwise false.</returns>
        public bool ValidateJulian(string julianDate)
        {
            return ProcessingDate.IsValidJulian(julianDate);
        }
        #endregion

        public string FormatGregorian(string gregorianDate)
        {
            DateTime date;
            if (ProcessingDate.IsValidGregorian(gregorianDate, out date))
            {
                return new ProcessingDate(date).ToGregorian();
            }
            else
            {
                throw new FormatException("The supplied string '" + gregorianDate + "' is not a valid Gregorian date");
            }
        }

        #region ConvertGregorianToJulian
        /// <summary>
        /// Converts the supplied Gregorian date to a Julian date in <c>yyjjj</c> format.
        /// </summary>
        /// <param name="gregorianDate">The date to convert.</param>
        /// <returns>
        /// The converted date.
        /// </returns>
        /// <exception cref="FormatException">
        /// The supplied string is not a valid Gregorian date.
        /// </exception>
        public string ConvertGregorianToJulian(string gregorianDate)
        {
            return ProcessingDate.FromGregorian(gregorianDate).ToJulian();
        }
        #endregion

        #region ConvertJulianToGregorian
        /// <summary>
        /// Converts the supplied Julian date to a Gregorian date in <c>dd/MMM/ccyy</c> format.
        /// </summary>
        /// <param name="julianDate">The date to convert.</param>
        /// <returns>
        /// The converted date, or an empty string if the supplied string is not a valid Julian date.
        /// </returns>
        public string ConvertJulianToGregorian(string julianDate)
        {
            return ProcessingDate.FromJulian(julianDate).ToGregorian();
        }
        #endregion
    }
}