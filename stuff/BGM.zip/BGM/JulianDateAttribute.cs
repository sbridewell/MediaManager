﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace BgmStuff.Models
{
    /// <summary>
    /// Decorate model properties of <see cref="Type"/> <see cref="string"/> with
    /// this attribute to have MVC validate that they contain a valid Julian date.
    /// </summary>
    /// <remarks><see href="http://www.c-sharpcorner.com/article/custom-data-annotation-validation-in-mvc/"/></remarks>
    public class JulianDateAttribute : ValidationAttribute
    {
        /// <summary>
        /// Determines whether the supplied value is a valid Julian date.
        /// </summary>
        /// <param name="value">The value to validate.</param>
        /// <param name="validationContext">
        /// Provides accesss to the <see cref="Type"/> of the model, the instance of the model
        /// and friendly display name of the property being validated.
        /// </param>
        /// <returns>
        /// Either <see cref="ValidationResult.Success"/> or a message indicating what is wrong.
        /// </returns>
        protected override ValidationResult IsValid(
            object value, 
            ValidationContext validationContext)
        {
            // must be a string
            string julianString = value as string;
            if (julianString == null)
            {
                // if this happens then we're validating a property of the wrong type
                return new ValidationResult("Not a string");
            }

            if (ProcessingDate.IsValidJulian(julianString))
            {
                return ValidationResult.Success;
            }
            else
            {
                return new ValidationResult("Must be 5 numeric characters in the format YYJJJ");
            }
        }
    }
}