﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BgmStuff.Models
{
    public class SearchModel
    {
        [Required]
        [Display(Name = "Date from")]
        [GregorianDate]
        public string DateFrom { get; set; }

        [Required]
        [Display(Name = "Date to")]
        [GregorianDate]
        public string DateTo { get; set; }

        [Required]
        [JulianDate]
        [Display(Name = "Julian date from")]
        public string JulianFrom { get; set; }

        [Required]
        [JulianDate]
        [Display(Name = "Julian date to")]
        public string JulianTo { get; set; }

        public string SearchResults { get; set; }
    }
}