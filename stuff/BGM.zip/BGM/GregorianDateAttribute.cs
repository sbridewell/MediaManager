﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BgmStuff.Models
{
    public class GregorianDateAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            // must be a string
            string julianString = value as string;
            if (julianString == null)
            {
                // if this happens then we're validating a property of the wrong type
                return new ValidationResult("Not a string");
            }

            if (ProcessingDate.IsValidGregorian(julianString))
            {
                return ValidationResult.Success;
            }
            else
            {
                return new ValidationResult("Must be a string representing a Gregorian date");
            }
        }
    }
}